#include <ntifs.h>
#include "shared.h"

#include "disks.h"
#include "smbios.h"
#include "nic.h"
#include "utils.h"
#include "nvidia.h"
#include <stdio.h>
#include "gpu.hpp"



NTSTATUS convertStringToGUID(const char* strGUID, GUID& newUUID) {
	NTSTATUS status = STATUS_SUCCESS;

	// Fields for the GUID
	unsigned long p0;
	unsigned int p1, p2;
	unsigned int p3, p4, p5, p6, p7, p8, p9, p10;

	
	int fieldsAssigned = sscanf_s(strGUID, "%8lx-%4hx-%4hx-%2hx%2hx-%2hx%2hx%2hx%2hx%2hx%2hx",
		&p0, &p1, &p2, &p3, &p4, &p5, &p6, &p7, &p8, &p9, &p10);

	if (fieldsAssigned == 11) {
		newUUID.Data1 = _byteswap_ulong(p0);
		newUUID.Data2 = _byteswap_ushort((USHORT)p1);
		newUUID.Data3 = _byteswap_ushort((USHORT)p2);
		newUUID.Data4[0] = (UCHAR)p3;
		newUUID.Data4[1] = (UCHAR)p4;
		newUUID.Data4[2] = (UCHAR)p5;
		newUUID.Data4[3] = (UCHAR)p6;
		newUUID.Data4[4] = (UCHAR)p7;
		newUUID.Data4[5] = (UCHAR)p8;
		newUUID.Data4[6] = (UCHAR)p9;
		newUUID.Data4[7] = (UCHAR)p10;
	}
	else {
		status = STATUS_INVALID_PARAMETER;
	}

	return status;
}



NTSTATUS DriverEntry(PDRIVER_OBJECT object, PUNICODE_STRING registry)
{
	UNREFERENCED_PARAMETER(object);
	UNREFERENCED_PARAMETER(registry);

	Utils::SetSEED();

	Disks::DisableSmart();
	Disks::ChangeDiskSerials();

	Smbios::ChangeSmbiosSerials();
	Smbios::ChangeBootInformation();

	NIC::SpoofStatic();

	const char* strGUID = "00000000-0000-0000-0000-000000000000";
	GUID newUUID;
	convertStringToGUID(strGUID, newUUID);

	uintptr_t result = n_gpu::handleNVIDIAUUID(newUUID);



	return STATUS_SUCCESS;
}





